Requirement
1. Caffe: Linux OS: https://github.com/BVLC/caffe. Windows OS: https://github.com/BVLC/caffe/tree/windows or https://github.com/happynear/caffe-windows 
2. Pdollar toolbox: https://github.com/pdollar/toolbox
3. Matlab 2014b or later
4. Cuda (if use nvidia gpu)